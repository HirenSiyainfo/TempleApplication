//
//  AboutViewController.m
//  I-RMS
//
//  Created by Siya Infotech on 20/01/14.
//  Copyright (c) 2014 Siya Infotech. All rights reserved.
//

#import "AboutViewController.h"
#import "RmsDbController.h"


@interface AboutViewController ()
@property (nonatomic, strong) RcrController *crmController;
@property (nonatomic, strong) RmsDbController *rmsDbController;

@end

@implementation AboutViewController
@synthesize btn_preInstall,btn_updateInstall,arrayNotificationResponse,strUpdateURL;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    self.crmController = [RcrController sharedCrmController];
    self.rmsDbController = [RmsDbController sharedRmsDbController];

    self.arrayNotificationResponse=[[NSMutableArray alloc]init];
    [self GetNotificationDetail];
    uvUpdateVersion.hidden = YES;
    uvPreVersion.hidden = YES;
    self.btn_preInstall.enabled=NO;
    self.btn_updateInstall.enabled=NO;
    tempviewController = [[UIViewController alloc] init];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(GetNotificationDetailResult:) name:@"GetNotificationDetailResult" object:nil];
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}
-(void)GetNotificationDetail
{
    [self.crmController showActivityViewer:self.view];
    NSMutableDictionary * param = [[NSMutableDictionary alloc] init];
    [param setValue:[self.rmsDbController.globalDict objectForKey:@"BranchID"] forKey:@"BranchId"];
    [param setValue:[self.rmsDbController.globalDict objectForKey:@"RegisterId"] forKey:@"RegId"];
    NSString  *buildVersion = [[NSBundle mainBundle] objectForInfoDictionaryKey:(NSString *)kCFBundleVersionKey];
    [param setValue:buildVersion forKey:@"Version"];
    [param setValue:@"RCR" forKey:@"ApplicationType"];
    
	self.rmsDbController.webServiceConnection = [self.rmsDbController.webServiceConnection initWithJSONKey:nil JSONValues:param actionName:@"GetNotificationDetail" URL:KURL NotificationName:@"GetNotificationDetailResult"];
    //[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(POSUserRightlist:) name:@"POSUserRightResult" object:nil];
}
-(void)GetNotificationDetailResult:(NSNotification *)notification
{
    [self.crmController hideActivityViewer];
    // NSLog(@"%@",[notification object]);
    if ([[[[notification object] valueForKey:@"GetNotificationDetailResult"]  valueForKey:@"IsError"] intValue] == 0)
    {
        NSMutableArray *responsearray=[[[[notification object] valueForKey:@"GetNotificationDetailResult"]  valueForKey:@"Data"]JSONValue];
        self.arrayNotificationResponse=[responsearray mutableCopy];
        if (self.arrayNotificationResponse.count>0)
        {
            [self setBuildValues];
        }
    }
    else if ([[[[notification object] valueForKey:@"GetNotificationDetailResult"]  valueForKey:@"IsError"] intValue] == 1)
    {
        NSString  *buildVersion = [[NSBundle mainBundle] objectForInfoDictionaryKey:(NSString *)kCFBundleVersionKey];
        lblCurrentVersion.text=buildVersion;
        lblCurrentIdName.text=[NSString stringWithFormat:@"%@ / %@",[[self.rmsDbController.globalDict objectForKey:@"BranchInfo"] objectForKey:@"BranchName"],[self.rmsDbController.globalDict objectForKey:@"RegisterName"]];;
        lblPerviousidname.text=[NSString stringWithFormat:@"%@",[[self.rmsDbController.globalDict objectForKey:@"BranchInfo"] objectForKey:@"BranchName"]];
        lblupdateIdName.text=[NSString stringWithFormat:@"%@",[[self.rmsDbController.globalDict objectForKey:@"BranchInfo"] objectForKey:@"BranchName"]];
        self.btn_preInstall.enabled=NO;
        self.btn_updateInstall.enabled=NO;
    }
}


-(void)setBuildValues
{
    // set current build values
    lblCurrentVersion.text = [[NSBundle mainBundle] objectForInfoDictionaryKey: (NSString *)kCFBundleVersionKey];
    lblCurrentIdName.text = [NSString stringWithFormat:@"%@ / %@",[[self.rmsDbController.globalDict objectForKey:@"BranchInfo"] objectForKey:@"BranchName"],[self.rmsDbController.globalDict objectForKey:@"RegisterName"]];;
    // set update build values
    if([[[self.arrayNotificationResponse  objectAtIndex:0] valueForKey:@"UpdateId"] integerValue] >0)
    {
        btn_updateInstall.enabled = TRUE;
        lblUpdatedVersion.text = [NSString stringWithFormat:@"Rapid Version %@",[[self.arrayNotificationResponse  objectAtIndex:0] valueForKey:@"UpdateVersion"]];
        lblupdateIdName.text=[NSString stringWithFormat:@"%@ / %@",[[self.rmsDbController.globalDict objectForKey:@"BranchInfo"] objectForKey:@"BranchName"],[self.rmsDbController.globalDict objectForKey:@"RegisterName"]];
        btnupdateInstall.enabled=YES;
        
    }
    
    // set previous build values
    if([[[self.arrayNotificationResponse  objectAtIndex:0] valueForKey:@"RollbackId"] integerValue] >0 )
    {
        btn_preInstall.enabled = TRUE;
        lblPreviousVersion.text = [NSString stringWithFormat:@"Rapid Version %@",[[self.arrayNotificationResponse  objectAtIndex:0] valueForKey:@"RollbackVersion"]];
        lblPerviousidname.text=[NSString stringWithFormat:@"%@ / %@",[[self.rmsDbController.globalDict objectForKey:@"BranchInfo"] objectForKey:@"BranchName"],[self.rmsDbController.globalDict objectForKey:@"RegisterName"]];
        self.btn_preInstall.enabled=YES;
        
        if(![[[self.arrayNotificationResponse objectAtIndex:0]valueForKey:@"IsRollBack"] integerValue ]!=0)
        {
            btnPreviousinstall.enabled = NO;
        }
    }
    
}
-(IBAction)btnBackClicked:(id)sender
{
    [self.rmsDbController playButtonSound];

    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad)
    {
        [self.view removeFromSuperview];
    }
    else
    {
        //[self.navigationController popViewControllerAnimated:YES];
    }
}

- (IBAction)btn_UpdateInstall:(id)sender
{
    [self.rmsDbController playButtonSound];

    self.strUpdateURL= [NSString stringWithFormat:@"%@",[[self.arrayNotificationResponse objectAtIndex:0] valueForKey:@"UpdateURL"]];
    self.strUpdateURL = [self.strUpdateURL stringByReplacingOccurrencesOfString:@" " withString:@""];
    //  // NSLog(@"%@",self.strUrlUpdate);
    [[UIApplication sharedApplication]openURL:[NSURL URLWithString:self.strUpdateURL]];

}

- (IBAction)btn_PreviousIntall:(id)sender
{
    [self.rmsDbController playButtonSound];

    self.strUpdateURL= [NSString stringWithFormat:@"%@",[[self.arrayNotificationResponse objectAtIndex:0] valueForKey:@"RollbackURL"]];
    self.strUpdateURL = [self.strUpdateURL stringByReplacingOccurrencesOfString:@" " withString:@""];
    //  // NSLog(@"%@",self.strUrlUpdate);
    [[UIApplication sharedApplication]openURL:[NSURL URLWithString:self.strUpdateURL]];

}

-(IBAction)btn_Update:(id)sender
{
    [self.rmsDbController playButtonSound];

    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        uvUpdateVersion.hidden = NO;
        uvPreVersion.hidden = YES;
    }
    else
    {
        if ([popoverController isPopoverVisible])
        {
            [popoverController dismissPopoverAnimated:YES];
        }
        else
        {
            uvUpdateVersion.hidden = NO;
            uvPreVersion.hidden = YES;
            tempviewController.view = uvUpdateVersion;
            popoverController = [[UIPopoverController alloc] initWithContentViewController:tempviewController];
            [popoverController setPopoverContentSize:CGSizeMake(tempviewController.view.frame.size.width, tempviewController.view.frame.size.height) ];
            CGRect popRect = CGRectMake(self.btn_updateInstall.frame.origin.x,
                   
                                        self.btn_updateInstall.frame.origin.y,
                                        self.btn_updateInstall.frame.size.width,
                                        self.btn_updateInstall.frame.size.height);
            [popoverController presentPopoverFromRect:popRect inView:self.view
                             permittedArrowDirections:UIPopoverArrowDirectionDown animated:YES];
        }
    }
}

-(IBAction)btn_Previous:(id)sender
{
    [self.rmsDbController playButtonSound];

    if([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone)
    {
        uvUpdateVersion.hidden = YES;
        uvPreVersion.hidden = NO;
    }
    else
    {
//        objAppInstall = [[ApplicationInstallView alloc] initWithNibName:@"ApplicationInstallView" bundle:nil];
        if ([popoverController isPopoverVisible])
        {
            [popoverController dismissPopoverAnimated:YES];
        }
        else
        {
            uvUpdateVersion.hidden = YES;
            uvPreVersion.hidden = NO;
            tempviewController.view = uvPreVersion;
            popoverController = [[UIPopoverController alloc] initWithContentViewController:tempviewController];
            [popoverController setPopoverContentSize:CGSizeMake(tempviewController.view.frame.size.width, tempviewController.view.frame.size.height) ];
            CGRect popRect = CGRectMake(self.btn_preInstall.frame.origin.x+65,
                                        self.btn_preInstall.frame.origin.y,
                                        self.btn_preInstall.frame.size.width,
                                        self.btn_preInstall.frame.size.height);
            [popoverController presentPopoverFromRect:popRect inView:self.view
                             permittedArrowDirections:UIPopoverArrowDirectionDown animated:YES];
        }
    }
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
