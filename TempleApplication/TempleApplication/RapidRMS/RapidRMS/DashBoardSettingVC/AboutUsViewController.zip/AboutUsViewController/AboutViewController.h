//
//  AboutViewController.h
//  I-RMS
//
//  Created by Siya Infotech on 20/01/14.
//  Copyright (c) 2014 Siya Infotech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutViewController : UIViewController
{
    IBOutlet UILabel *lblCurVersion;
    IBOutlet UILabel *lblCurVerDate_Time;
    IBOutlet UIButton *btnPreviousinstall;
    
    IBOutlet UIButton *btnupdateInstall;
    IBOutlet UILabel *lblPerviousidname;
    IBOutlet UILabel *lblupdateIdName;
    IBOutlet UILabel *lblCurrentIdName;
    IBOutlet UILabel *lblPreviousVersion;
    IBOutlet UILabel *lblUpdatedVersion;
    IBOutlet UILabel *lblCurrentVersion;
    IBOutlet UIView *uvUpdateVersion;
    IBOutlet UIView *uvPreVersion;
    UIPopoverController *popoverController;
    UIViewController *tempviewController;
    NSMutableArray *arrayNotificationResponse;
}
- (IBAction)btn_UpdateInstall:(id)sender;
- (IBAction)btn_PreviousIntall:(id)sender;

-(IBAction)btn_Update:(id)sender;
-(IBAction)btn_Previous:(id)sender;
@property (nonatomic, retain)NSMutableArray *arrayNotificationResponse;
@property (nonatomic, retain) NSString *strUpdateURL;
@property (nonatomic, retain) IBOutlet UIButton *btn_preInstall;
@property (nonatomic, retain) IBOutlet UIButton *btn_updateInstall;

@end
